# healthCity
To collect and analyse health data according to geographic location
